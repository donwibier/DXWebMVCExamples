namespace DXWebNWind.Code.NWindEF
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("Alphabetical list of products")]
    public partial class Alphabetical_list_of_products
    {
        [Key]
        [Column(Order = 0)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int ProductID { get; set; }

        [Key]
        [Column(Order = 1)]
        [StringLength(40)]
        public string ProductName { get; set; }

        public int? SupplierID { get; set; }

        public int? CategoryID { get; set; }

        [StringLength(20)]
        public string QuantityPerUnit { get; set; }

        [Column(TypeName = "smallmoney")]
        public decimal? UnitPrice { get; set; }

        public short? UnitsInStock { get; set; }

        public short? UnitsOnOrder { get; set; }

        public short? ReorderLevel { get; set; }

        [Key]
        [Column(Order = 2)]
        public bool Discontinued { get; set; }

        [Key]
        [Column(Order = 3)]
        [StringLength(15)]
        public string CategoryName { get; set; }

        public virtual Categories Categories { get; set; }

        public virtual Products Products { get; set; }

        public virtual Suppliers Suppliers { get; set; }
    }
}
